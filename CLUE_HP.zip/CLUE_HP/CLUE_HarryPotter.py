import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import random

class ClueHarryPotter:
    def __init__(self, root):
        self.root = root
        self.root.title("🧙‍♂️ CLUE: Edición Harry Potter")
        self.root.geometry("1000x600")
        self.root.config(bg="#2e1a47")

        # Canvas para scroll
        self.canvas = tk.Canvas(self.root, bg="#2e1a47", highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas, style="Card.TFrame")

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        # Datos del juego
        self.personajes = {
            "Harry Potter": {"profesion": "Estudiante", "imagen": "Harry.jpg"},
            "Hermione Granger": {"profesion": "Estudiante", "imagen": "Hermione.jpg"},
            "Ron Weasley": {"profesion": "Estudiante", "imagen": "Ron.jpg"},
            "Albus Dumbledore": {"profesion": "Director", "imagen": "Dumbledore.jpg"},
            "Severus Snape": {"profesion": "Profesor de Pociones", "imagen": "Snape.jpg"}
        }

        self.locaciones = [
            {"nombre": "El Gran Comedor", "imagen": "Comedor.jpg"},
            {"nombre": "La Biblioteca", "imagen": "Biblioteca.jpg"},
            {"nombre": "El Despacho del Director", "imagen": "Despacho.jpg"},
            {"nombre": "Sala de Menesteres", "imagen": "Salon.jpg"},
            {"nombre": "Las Mazmorras", "imagen": "Mazmorras.jpg"}
        ]

        self.armas = [
            {"nombre": "Varita de Saúco", "imagen": "Varita.jpg"},
            {"nombre": "Maldición Cruciatus", "imagen": "Crucius.jpg"},
            {"nombre": "Poción Multijugos", "imagen": "Pocion.jpg"},
            {"nombre": "Libro de Monstruos", "imagen": "Libro.jpg"},
            {"nombre": "Colmillo de Basilisco", "imagen": "Colmillo.jpg"}
        ]

        self.crear_estilos()
        self.imagenes = {}
        self.crear_interfaz()
        self.iniciar_juego()

    def crear_estilos(self):
        style = ttk.Style()
        style.configure("Card.TFrame", background="#f2e9f3")
        style.configure("TLabel", background="#f2e9f3", font=("Segoe UI", 11))
        style.configure("TButton", font=("Segoe UI", 10, "bold"))
        style.map("TButton", background=[("active", "#c2b6e3")])
        style.configure("Title.TLabel", background="#2e1a47", foreground="white", font=("Segoe UI", 24, "bold"))

    def cargar_imagen(self, nombre_archivo, ancho=50, alto=50):
        try:
            imagen = Image.open(nombre_archivo)
            imagen = imagen.resize((ancho, alto), Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(imagen)
        except FileNotFoundError:
            print(f"Error: No se encontró la imagen '{nombre_archivo}'")
            return None

    def generar_solucion(self):
        personaje = random.choice(list(self.personajes.keys()))
        locacion = random.choice(self.locaciones)["nombre"]
        arma = random.choice(self.armas)["nombre"]
        return {"personaje": personaje, "locacion": locacion, "arma": arma}

    def repartir_cartas(self):
        mazo = list(self.personajes.keys()) + [l["nombre"] for l in self.locaciones] + [a["nombre"] for a in self.armas]
        random.shuffle(mazo)
        return random.sample(mazo, 6)

    def iniciar_juego(self):
        self.solucion = self.generar_solucion()
        self.mano_jugador = self.repartir_cartas()

        self.lista_cartas.delete(0, tk.END)
        for carta in self.mano_jugador:
            self.lista_cartas.insert(tk.END, carta)

        self.mensaje_area.config(state=tk.NORMAL)
        self.mensaje_area.delete(1.0, tk.END)
        self.mensaje_area.config(state=tk.DISABLED)

        self.mostrar_mensaje("🧙‍♂️ ¡Bienvenido a CLUE: Edición Harry Potter!")
        self.mostrar_mensaje(f"📜 Tu mano: {', '.join(self.mano_jugador)}")

    def crear_interfaz(self):
        frame = self.scrollable_frame
        ttk.Label(frame, text="🔮 CLUE: Edición Harry Potter", style="Title.TLabel").pack(pady=20)

        info_frame = ttk.LabelFrame(frame, text="🪄 Tu Información")
        info_frame.pack(padx=20, pady=10, fill="x")

        tk.Label(info_frame, text="Tus Cartas:").pack(pady=5)
        self.lista_cartas = tk.Listbox(info_frame, width=50, font=("Segoe UI", 10))
        self.lista_cartas.pack(pady=5)

        sospecha_frame = ttk.LabelFrame(frame, text="🔍 Realizar Sospecha")
        sospecha_frame.pack(padx=20, pady=10, fill="x")

        self.personaje_seleccionado = self.crear_combobox_con_imagen(
            sospecha_frame, "Personaje:", 0,
            list(self.personajes.keys()),
            self.personajes)

        self.locacion_seleccionada = self.crear_combobox_con_imagen(
            sospecha_frame, "Locación:", 1,
            [loc["nombre"] for loc in self.locaciones],
            {loc["nombre"]: {"imagen": loc["imagen"]} for loc in self.locaciones})

        self.arma_seleccionada = self.crear_combobox_con_imagen(
            sospecha_frame, "Arma:", 2,
            [arma["nombre"] for arma in self.armas],
            {arma["nombre"]: {"imagen": arma["imagen"]} for arma in self.armas})

        self.boton_sospechar = tk.Button(sospecha_frame, text="🔍 ¡Sospechar!", command=self.realizar_sospecha, bg="#c2b6e3")
        self.boton_sospechar.grid(row=3, columnspan=2, pady=10)

        acusacion_frame = ttk.LabelFrame(frame, text="⚡ Realizar Acusación")
        acusacion_frame.pack(padx=20, pady=10, fill="x")

        self.acusacion_personaje = self.crear_combobox_con_imagen(acusacion_frame, "Personaje:", 0, list(self.personajes.keys()), self.personajes)
        self.acusacion_locacion = self.crear_combobox_con_imagen(acusacion_frame, "Locación:", 1, [loc["nombre"] for loc in self.locaciones], {loc["nombre"]: {"imagen": loc["imagen"]} for loc in self.locaciones})
        self.acusacion_arma = self.crear_combobox_con_imagen(acusacion_frame, "Arma:", 2, [arma["nombre"] for arma in self.armas], {arma["nombre"]: {"imagen": arma["imagen"]} for arma in self.armas})

        self.boton_acusar = tk.Button(acusacion_frame, text="⚔️ ¡Acusar!", command=self.realizar_acusacion, bg="#ffb3b3")
        self.boton_acusar.grid(row=3, columnspan=2, pady=10)

        self.boton_reiniciar = tk.Button(frame, text="🔄 Reiniciar Juego", command=self.iniciar_juego, bg="#ddd")
        self.boton_reiniciar.pack(pady=10)

        self.mensaje_area = tk.Text(frame, height=5, state=tk.DISABLED, bg="#fffaf0", font=("Consolas", 10))
        self.mensaje_area.pack(padx=20, pady=10, fill="both", expand=True)

    def crear_combobox_con_imagen(self, parent, label_text, row, opciones, data_con_imagen):
        tk.Label(parent, text=label_text).grid(row=row, column=0, padx=5, pady=5, sticky="w")
        combo_frame = tk.Frame(parent, bg="#f2e9f3")
        combo_frame.grid(row=row, column=1, padx=5, pady=5, sticky="ew")
        combo = ttk.Combobox(combo_frame, values=opciones, state="readonly")
        combo.set(opciones[0])
        combo.pack(side="left")

        imagen_label = tk.Label(combo_frame, bg="#f2e9f3")
        imagen_label.pack(side="right", padx=5)

        def actualizar_imagen(event):
            seleccion = combo.get()
            if seleccion in data_con_imagen and "imagen" in data_con_imagen[seleccion]:
                imagen_tk = self.cargar_imagen(data_con_imagen[seleccion]["imagen"], ancho=40, alto=40)
                if imagen_tk:
                    imagen_label.config(image=imagen_tk)
                    imagen_label.image = imagen_tk

        combo.bind("<<ComboboxSelected>>", actualizar_imagen)
        actualizar_imagen("<<ComboboxSelected>>")

        return combo

    def mostrar_mensaje(self, mensaje):
        self.mensaje_area.config(state=tk.NORMAL)
        self.mensaje_area.insert(tk.END, mensaje + "\n")
        self.mensaje_area.config(state=tk.DISABLED)
        self.mensaje_area.see(tk.END)

    def realizar_sospecha(self):
        personaje = self.personaje_seleccionado.get()
        locacion = self.locacion_seleccionada.get()
        arma = self.arma_seleccionada.get()
        self.mostrar_mensaje(f"🕵️ Sospecha: {personaje} en {locacion} con {arma}.")

        pistas = [i for i in [personaje, locacion, arma] if i in self.mano_jugador]
        if pistas:
            self.mostrar_mensaje(f"✨ Tienes estas cartas: {', '.join(pistas)}")
        else:
            self.mostrar_mensaje("😱 ¡No tienes ninguna de esas cartas!")

    def realizar_acusacion(self):
        acusacion = {
            "personaje": self.acusacion_personaje.get(),
            "locacion": self.acusacion_locacion.get(),
            "arma": self.acusacion_arma.get()
        }
        if acusacion == self.solucion:
            self.mostrar_mensaje("🎉 ¡Has resuelto el misterio correctamente! ¡Ganaste!")
        else:
            self.mostrar_mensaje("❌ Acusación incorrecta. ¡Sigue investigando!")

# Ejecutar
if __name__ == "__main__":
    root = tk.Tk()
    app = ClueHarryPotter(root)
    root.mainloop()
